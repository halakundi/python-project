from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

# Import backend logic
from models.library import register_member, borrow_book, return_book, get_books

app = FastAPI(title="Library Management System")

# Mount static + templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ---------------- Routes ----------------
@app.get("/", response_class=HTMLResponse)
def home(request: Request, msg: str = None):
    books = get_books()
    return templates.TemplateResponse("index.html", {"request": request, "books": books, "msg": msg})

@app.post("/register", response_class=HTMLResponse)
def register(request: Request, name: str = Form(...)):
    member_id = register_member(name)
    msg = f"✅ Registered {name}, ID: {member_id}"
    books = get_books()
    return templates.TemplateResponse("index.html", {"request": request, "books": books, "msg": msg})

@app.post("/borrow", response_class=HTMLResponse)
def borrow(request: Request, member_id: int = Form(...), book_id: int = Form(...)):
    success, msg = borrow_book(member_id, book_id)
    books = get_books()
    return templates.TemplateResponse("index.html", {"request": request, "books": books, "msg": msg})

@app.post("/return", response_class=HTMLResponse)
def returnb(request: Request, member_id: int = Form(...), book_id: int = Form(...)):
    success, msg = return_book(member_id, book_id)
    books = get_books()
    return templates.TemplateResponse("index.html", {"request": request, "books": books, "msg": msg})
