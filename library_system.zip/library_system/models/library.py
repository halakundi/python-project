from datetime import datetime, timedelta
import time

# ---------------- Data ----------------
books = [
    {"id": 1, "title": "Data Structures in Python", "author": "Author A", "isbn": "123456789", "availability": True},
    {"id": 2, "title": "Algorithms in Java", "author": "Author B", "isbn": "987654321", "availability": True},
    {"id": 3, "title": "Principles of AI", "author": "Author C", "isbn": "1234509876", "availability": True},
]

members = {}
borrowed_books = {}

# ---------------- Core Logic ----------------
def register_member(name: str):
    member_id = int(time.time())  # Simple unique ID
    members[member_id] = {"name": name, "borrowed_books": []}
    return member_id

def borrow_book(member_id: int, book_id: int):
    book = next((b for b in books if b["id"] == book_id), None)
    if not book:
        return False, "❌ Invalid book ID."
    if not book["availability"]:
        return False, "❌ Book unavailable."
    if member_id not in members:
        return False, "❌ Member not found."

    # Borrow limit: 3 books
    if len(borrowed_books.get(member_id, [])) >= 3:
        return False, "❌ Borrow limit reached (3 books)."

    book["availability"] = False
    due_date = datetime.now() + timedelta(days=7)
    borrowed_books.setdefault(member_id, []).append({"book_id": book_id, "due_date": due_date})

    return True, f"📖 Borrowed successfully! Due date: {due_date.strftime('%Y-%m-%d')}"

def return_book(member_id: int, book_id: int):
    book = next((b for b in books if b["id"] == book_id), None)
    if not book:
        return False, "❌ Invalid book ID."
    if member_id not in members:
        return False, "❌ Member not found."

    borrowed_list = borrowed_books.get(member_id, [])
    borrowed_entry = next((entry for entry in borrowed_list if entry["book_id"] == book_id), None)

    if not borrowed_entry:
        return False, "❌ This book was not borrowed by the member."

    book["availability"] = True
    borrowed_list.remove(borrowed_entry)

    now = datetime.now()
    if now > borrowed_entry["due_date"]:
        late_days = (now - borrowed_entry["due_date"]).days
        fine = late_days * 10
        return True, f"✅ Returned late by {late_days} days! Fine: ₹{fine}"
    return True, "✅ Returned on time!"

def get_books():
    return books
